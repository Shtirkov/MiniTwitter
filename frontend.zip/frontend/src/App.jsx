import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Box } from "@chakra-ui/react";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Feed from "./pages/Feed";
import Profile from "./pages/Profile";
import Navbar from "./Navbar";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" />} />

        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route
          path="/feed"
          element={
            <Box minH="100vh" w="100%">
              <Navbar />
              <Feed />
            </Box>
          }
        />
        <Route
          path="/profile"
          element={
            <Box minH="100vh" w="100%">
              <Navbar />
              <Profile />
            </Box>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
